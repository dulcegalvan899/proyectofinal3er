# proyecto final de 3er semestre
Proyecto Final de la Clase de 3er Semestre de Emplea Frameworks
Este software esta desarrollado en Python, y cuenta con una
pantalla principal, un registro de productos, registro de ventas
y la impresión del Ticket.

Al momento se está creando su repositorio y los logos que se
usarán en el software.
