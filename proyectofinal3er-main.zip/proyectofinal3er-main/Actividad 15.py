#Repaso actividad 15

import tkinter as tk

ventana = tk.Tk()   #Crea una ventana nueva
ventana.title("Act. 15 de NOMBRE")
ventana.geometry("150x150")

#Activamos la ventana
ventana.mainloop()

